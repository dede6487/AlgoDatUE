#include<iostream>

#include "AVL.h"

using namespace std;

//for this task I reused the structure of the previously made Binary Search Tree
//because I had an unresolved Error with this HW, I also wasn't able to test the AVL propperly

int main() {

	//ERROR: LNK2019 in VS - Verweis auf nicht aufgel�stes externes Symbol
	//I couldn't resolve this error, so I wasn't able to test

	//AVLTree<int> a;
	//a.empty();
	//
	//if (a.isempty()) {
	//	cout << "a is empty" << endl;
	//}
	//else {
	//	cout << "a is not empty" << endl;
	//}

	//a.insert(1);//insert doesn't work
	//a.insert(2);
	//a.insert(3);
	//a.insert(42);

	//if (a.member(2)) {
	//	cout << "2 is member of a" << endl;
	//}
	//else {
	//	cout << "2 is not member of a" << endl;
	//}

	//a.del(2);//because insert does not work, delete aborts

	//if (a.member(2)) {
	//	cout << "2 is member of a" << endl;
	//}
	//else {
	//	cout << "2 is not member of a" << endl;
	//}

	//return 0;
}
