#include "AMatrix.h"
#include "AList.h"
#include "QuickSort.h"

//due to time problems I resorted to only implement parts of this assignment

int main(){
    
}