#include <iostream>
#include "CircularQueue.h"
using namespace std;

template <class T>
CircularQueue<T>::CircularQueue() {
}

template <class T>
CircularQueue<T>::~CircularQueue() {}

template <class T>
void CircularQueue<T>::enqueue(T element) {
}

template <class T>
void CircularQueue<T>::dequeue() {
}

template <class T>
T CircularQueue<T>::front() {
}

template <class T>
bool CircularQueue<T>::isEmpty() {
}

template <class T>
bool CircularQueue<T>::isFull() { 
}

template <class T>
void CircularQueue<T>::printQueue () {
}

template class CircularQueue<int>;

