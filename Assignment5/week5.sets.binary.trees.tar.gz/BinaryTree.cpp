#include <iostream>
#include "BinaryTree.h"
using namespace std;

template <class T>
BinaryTree<T>::BinaryTree() {
}

template <class T>
BinaryTree<T>::~BinaryTree() {
}

template <class T>
void BinaryTree<T>::empty() {
}

template <class T>
void BinaryTree<T>::makeTree(BinaryTree& leftT, T element, BinaryTree& rightT) {
}

template <class T>
T BinaryTree<T>::key() {
}

template <class T>
BinaryTree<T> BinaryTree<T>::leftTree() {
}

template <class T>
BinaryTree<T> BinaryTree<T>::rightTree() {
}

template <class T>
void BinaryTree<T>::printBinaryTree() {
}

template class BinaryTree<int>;

