#include <iostream>
#include "Queue.h"
using namespace std;

template <class T>
Queue<T>::Queue() {
}

template <class T>
Queue<T>::~Queue() {}

template <class T>
void Queue<T>::enqueue(T element) {
}

template <class T>
void Queue<T>::dequeue() {
}

template <class T>
T Queue<T>::front() {
}

template <class T>
bool Queue<T>::isEmpty() {
}

template <class T>
bool Queue<T>::isFull() { 
}

template <class T>
void Queue<T>::printQueue () {
}

template class Queue<int>;

